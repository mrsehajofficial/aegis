"""Anti-spam detector — V0.5 implementation."""
