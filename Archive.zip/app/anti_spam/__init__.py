"""Anti-spam domain — V0.5 implementation."""
