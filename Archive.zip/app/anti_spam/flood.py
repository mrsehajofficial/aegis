"""
flood.py — Sliding-window flood detector. V0.5 implementation.

Algorithm (planned):
  - Track per-user message timestamps in a deque
  - Window: configurable (default 5 msgs / 3 seconds per group settings)
  - On trigger: delete messages + mute user for configurable duration
"""
