"""Anti-spam actions — V0.5 implementation."""
