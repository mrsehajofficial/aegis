"""Resolve a target user from a lookup token (@username or numeric ID).

Telegram's getChatMember does not reliably accept @usernames, so a
@username is first resolved to a numeric user ID via getChat, then the
membership is fetched by ID.
"""
from typing import Optional, Union

from telegram import ChatMember
from telegram.ext import ContextTypes


async def resolve_member(
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    lookup: Union[str, int, None],
) -> Optional[ChatMember]:
    """Resolve '@username' or a numeric user ID to a ChatMember.

    Returns the ChatMember, or None if Telegram can't resolve it
    (e.g. the user hides their username visibility).
    """
    if lookup is None:
        return None
    try:
        if isinstance(lookup, str):
            if not lookup.startswith("@"):
                return None
            # Step 1: username -> numeric user ID
            user_chat = await context.bot.get_chat(lookup)
            # Step 2: numeric ID -> member of this chat
            return await context.bot.get_chat_member(chat_id, user_chat.id)
        return await context.bot.get_chat_member(chat_id, lookup)
    except Exception:
        return None
