import logging
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    ChatMemberHandler,
    MessageHandler,
    filters as ptb_filters,
)

from app.config.settings import settings
from app.bot.handlers.commands import (
    help_command,
    id_command,
    info_command,
    admins_command,
)
from app.bot.handlers.moderation import (
    ban_command,
    unban_command,
    kick_command,
    mute_command,
    unmute_command,
    warn_command,
    warnings_command,
    resetwarns_command,
    purge_command,
    pin_command,
    unpin_command,
    logs_command,
)
from app.bot.handlers.filters import filter_command, filters_command, stop_command, check_filters
from app.bot.handlers.welcome import (
    welcome_command,
    setwelcome_command,
    goodbye_command,
    setgoodbye_command,
    rules_command,
    setrules_command,
    settings_command,
    setwarnlimit_command,
)
from app.bot.handlers.lifecycle import handle_my_chat_member
from app.bot.handlers.errors import error_handler
from app.bot.helpers.ensure_group import ensure_group_registered
from app.bot.middleware.auth import is_super_admin
from app.bot.middleware.throttling import check_rate_limit

logger = logging.getLogger(__name__)


def build_application() -> Application:
    """Build and configure the PTB Application with all registered handlers."""
    app = (
        ApplicationBuilder()
        .token(settings.BOT_TOKEN)
        .build()
    )

    # ── Information Commands ──────────────────────────────────────────────────
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("id", id_command))
    app.add_handler(CommandHandler("info", info_command))
    app.add_handler(CommandHandler("admins", admins_command))

    # ── Moderation Commands ─────────────────────────────────────────────────────
    app.add_handler(CommandHandler("ban", ban_command))
    app.add_handler(CommandHandler("unban", unban_command))
    app.add_handler(CommandHandler("kick", kick_command))
    app.add_handler(CommandHandler("mute", mute_command))
    app.add_handler(CommandHandler("unmute", unmute_command))
    app.add_handler(CommandHandler("warn", warn_command))
    app.add_handler(CommandHandler("warnings", warnings_command))
    app.add_handler(CommandHandler("resetwarns", resetwarns_command))
    app.add_handler(CommandHandler("purge", purge_command))
    app.add_handler(CommandHandler("pin", pin_command))
    app.add_handler(CommandHandler("unpin", unpin_command))
    app.add_handler(CommandHandler("logs", logs_command))

    # ── Group / Welcome Commands ──────────────────────────────────────────────
    app.add_handler(CommandHandler("rules", rules_command))
    app.add_handler(CommandHandler("setrules", setrules_command))
    app.add_handler(CommandHandler("welcome", welcome_command))
    app.add_handler(CommandHandler("setwelcome", setwelcome_command))
    app.add_handler(CommandHandler("goodbye", goodbye_command))
    app.add_handler(CommandHandler("setgoodbye", setgoodbye_command))
    app.add_handler(CommandHandler("settings", settings_command))
    app.add_handler(CommandHandler("setwarnlimit", setwarnlimit_command))

    # ── Filter Commands ───────────────────────────────────────────────────────
    app.add_handler(CommandHandler("filter", filter_command))
    app.add_handler(CommandHandler("filters", filters_command))
    app.add_handler(CommandHandler("stop", stop_command))

    # ── Filter auto-replies (non-command text) ────────────────────────────────
    app.add_handler(MessageHandler(ptb_filters.TEXT & ~ptb_filters.COMMAND, check_filters))

    # ── Bot Lifecycle (my_chat_member) ────────────────────────────────────────
    app.add_handler(ChatMemberHandler(handle_my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER))

    # ── Global Error Handler ──────────────────────────────────────────────────
    app.add_error_handler(error_handler)

    logger.info("All handlers registered.")
    return app
